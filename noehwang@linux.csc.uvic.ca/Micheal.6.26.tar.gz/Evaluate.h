//
//  Evaluate.h
//  2connect2
//
//  Created by Noe Hwang on 13-06-23.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#ifndef EVALUATE_H
#define EVALUATE_H
#include "globalDefines.h"

int checkCompForEval(int last_col, int total_rows, int* board);
#endif
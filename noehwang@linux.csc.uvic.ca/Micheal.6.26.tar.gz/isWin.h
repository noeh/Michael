//
//  isWin.h
//  2connect2
//
//  Created by Noe Hwang on 13-06-23.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#ifndef ISWIN_H
#define ISWIN_H
#include "globalDefines.h"
int checkComp(int last_col, int total_rows, int* board);
#endif